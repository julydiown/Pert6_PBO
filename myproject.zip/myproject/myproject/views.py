from django.shortcuts import render

def beranda(request):
    return render(request, 'beranda.html')

def dokumentasi(request):
    return render(request, 'dokumentasi.html')

def signin(request):
    return render(request, 'signin.html')    

