from django.apps import AppConfig


class myprojectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myproject'
